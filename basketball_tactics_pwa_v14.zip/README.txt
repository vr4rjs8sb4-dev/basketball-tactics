Basketball Tactics PWA (v1.4)

公開手順（GitHub Pages）
1. GitHubにログインして新しいPublicリポジトリを作成します。
2. このZIPを解凍し、index.html / manifest.webmanifest / sw.js / icon-*.png をリポジトリのルートにアップロードします（フォルダごとではなく中のファイル）。
3. Settings → Pages → Build and deployment → Deploy from a branch → main / (root) → Save。
4. 表示された https://ユーザー名.github.io/リポジトリ名/ をSafariで開きます。
5. Safariの共有 → ホーム画面に追加。友達には同じURLを共有できます。

注意：このZIPだけでは公開URLは発行されません。GitHub Pages等へのアップロードが必要です。
公開後の更新ではキャッシュ名を変えるとオフライン版の更新が確実になります。
